Jemuel's CMD Tools
=================
This is a collection of CMD Tools used for DevOps scripts.